import { useState } from 'react';
import './App.css'
import { AiOutlineUserAdd } from "react-icons/ai";
import { TiDeleteOutline } from "react-icons/ti";
import { FaRegEdit } from "react-icons/fa";
import { MdOutlineDelete } from "react-icons/md";

function App() {

  const[display , setDisplay] = useState(-430)
  const[editIndex , SeteditIndex] = useState(null)
  const[Students, setStudents] = useState([])
  const[form , setForm] = useState({
    fullname:'',
    class : '',
    roll:'',
    subject:'',
    date:''
  })

  const show = () => {
    setDisplay(0)
  }

  const handleInput = (e) => {
    const input= e.target;
    const value = input.value;
    console.log(value);
    const key = input.name;
    setForm({
      ...form,
      [key]  : value
    })
  }
  
  const createStudent = (e) => {
    e.preventDefault();
    setStudents([
      ...Students,
      form
    ])
    setForm({
      fullname:'',
    class : '',
    roll:'',
    subject:'',
    date:''
    })
    setDisplay(-430)
  }

  const deleteList = (index) =>{
    const backup = [...Students];
    backup.splice(index , 1);
    setStudents(backup);
  }

 const editStudents =(index) => {
  setDisplay(0);
  setForm (Students[index])
  SeteditIndex(index)
 }
 const saveStudents = (e) => {
  e.preventDefault()
  setForm({
    fullname:'',
  class : '',
  roll:'',
  subject:'',
  date:''
  })
  setDisplay(-430);
  SeteditIndex(null)
  const backup = [...Students];
  backup[editIndex] = form
  setStudents(backup)
 }

 const crossicon = () => {
  setDisplay(-430)
  setForm({
    fullname:'',
  class : '',
  roll:'',
  subject:'',
  date:''
  })
  SeteditIndex(null)
 }
  return (
    <>
    
      <div style={{
          backgroundColor: '#ddd',
          minHeight: '100vh'
      }}>

        <div style={{
          backgroundColor:'white',
          width:'80%',
          margin:'0 auto',
          padding:14,
          marginTop:24
        }}>


          <h1 style={{textAlign:'center',}}>Registration Students</h1>

          <button style={{
            border:'none',
            padding:"12px 24px",
            borderRadius: 4,
            color:'white',
            background:'#8507BA',
            margin: '24px 0px'
          }}
          onClick={show}
          >
            <AiOutlineUserAdd style={{marginRight:5}}/>
            New Student
          </button>

          <table className='student-table'>
            <thead>
              <tr>
                <th>S/No</th>
                <th>Student's Name</th>
                <th>Subject</th>
                <th>Class</th>
                <th>Roll</th>
                <th>Date</th>
                <th>Action</th>
              </tr>
            </thead>

             <tbody>
           {Students.map((items , index )=>(
             <tr>
               <td>{index+1}</td>
               <td>{items.fullname}</td>
               <td>{items.subject}</td>
               <td>{items.class}</td>
               <td>{items.roll}</td>
               <td>{items.date}</td>
              
               <td>
                 <div>
                   <button style={{
                     border:'none',
                     width:32,
                     height:32,
                     background:'#07c65d',
                     color:'white',
                     borderRadius:4,
                     marginRight:5,
                     fontSize:18}}
                     onClick={()=>editStudents(index)}>
                   <FaRegEdit />
                   </button>
                   <button style={{
                     border:'none',
                     width:32,
                     height:32,
                     background:'red',
                     color:'white',
                     borderRadius:4,
                     fontSize:18}}
                     onClick={()=>deleteList(index)}>
                   <MdOutlineDelete />
                   </button>
                 </div>
               </td>
             
             </tr>
           ))}
           </tbody>
          </table>
        </div>

        <aside style={{
          width:430,
          background:'white',
          position:'fixed',
          top:0,
          right:display,
          height:'99vh',
          boxShadow:"0 0 40px rgba(0,0,0,0.2)",
          transition:'1s'
        }}>
          <h2 style={{
            fontSize:'30px',
            textAlign:'left',
            margin:15
          }}>
            New Student
            </h2>

            <TiDeleteOutline style={{
              fontSize:28,
              position:'absolute',
              top:20,
              right:20,
              color:'#8507BA'
            }}
            onClick={crossicon}
            />

            <form style={{
              display:'flex',
              flexDirection:'column',
              gap:24,
              padding:20
            }}
            onSubmit={editIndex === null ? createStudent : saveStudents}
            >
              <input type='text'
              onChange={handleInput}
              name='fullname'
              value={form.fullname}
              placeholder='Enter Your FullName Here'
              style={{
                padding:8,
                border:'1px solid #ddd'
              }}/>
              
              <input type='text'
              onChange={handleInput}
              name='class'
              value={form.class}
              placeholder='Enter your Class'
              style={{
                padding:8,
                border:'1px solid #ddd'
              }}/>
               
               <input type='number'
               onChange={handleInput}
               name='roll'
               value={form.roll}
              placeholder='Enter your Roll'
              style={{
                padding:8,
                border:'1px solid #ddd'
              }}/>
              
              <input type='text'
              onChange={handleInput}
              name='subject'
              value={form.subject}
              placeholder='Enter your Subject Here'
              style={{
                padding:8,
                border:'1px solid #ddd'
              }}/>
              
              <input type='date'
              onChange={handleInput}
              name='date'
              value={form.date}
              style={{
                padding:8,
                border:'1px solid #ddd'
              }}/>

              {
                editIndex === null ?
                 <button style={{
                  border:'none',
                  padding:'12px',
                  borderRadius:4,
                  background:'#8507BA',
                  color:"white"
                }}>Submite</button>
                :
                <button style={{
                  border:'none',
                  padding:'12px',
                  borderRadius:4,
                  background:'deeppink',
                  color:"white"
                }}>Save</button>
              }
                

                
            </form>
        </aside>
      </div>
    </>
  )
}

export default App
